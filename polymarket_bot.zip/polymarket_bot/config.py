"""
config.py — Central configuration for Polymarket Auto-Trading Bot
"""

from dataclasses import dataclass, field
from typing import List

# ─────────────────────────────────────────────
# TRADING PARAMETERS
# ─────────────────────────────────────────────
@dataclass
class TradingConfig:
    assets: List[str] = field(default_factory=lambda: ["BTC", "ETH", "SOL"])
    timeframe: str = "15m"
    max_open_positions: int = 3
    min_bet: float = 1.2
    max_bet: float = 2.0
    take_profit: float = 0.50        # +50%
    stop_loss: float = -0.30         # -30%
    time_exit_minutes: int = 30      # force close after 30 min

# ─────────────────────────────────────────────
# EDGE / ENTRY RULES
# ─────────────────────────────────────────────
@dataclass
class EdgeConfig:
    min_edge: float = 0.08           # EDGE >= 8%
    min_confidence: float = 0.60     # Model confidence > 60%
    max_spread: float = 0.05         # Max spread 5%
    min_liquidity_usdc: float = 500  # Min liquidity in market

# ─────────────────────────────────────────────
# RISK MANAGEMENT
# ─────────────────────────────────────────────
@dataclass
class RiskConfig:
    max_daily_loss: float = 10.0     # Max $10 loss per day
    max_consecutive_loss: int = 3    # Pause after 3 consecutive losses
    cooldown_minutes: int = 10       # Cooldown after loss streak
    min_winrate_window: int = 20     # Rolling window for winrate check
    min_winrate: float = 0.40        # Stop if winrate < 40%

# ─────────────────────────────────────────────
# ML MODEL
# ─────────────────────────────────────────────
@dataclass
class MLConfig:
    model_type: str = "xgboost"      # "xgboost", "random_forest", "ensemble"
    lookback_candles: int = 50       # Historical candles for features
    retrain_interval_hours: int = 24 # Retrain model every 24 hours
    min_train_samples: int = 500     # Minimum samples before training
    feature_version: str = "v1"

# ─────────────────────────────────────────────
# BINANCE API
# ─────────────────────────────────────────────
@dataclass
class BinanceConfig:
    api_key: str = ""                # Set via env: BINANCE_API_KEY
    api_secret: str = ""             # Set via env: BINANCE_API_SECRET
    base_url: str = "https://api.binance.com"
    symbol_map: dict = field(default_factory=lambda: {
        "BTC": "BTCUSDT",
        "ETH": "ETHUSDT",
        "SOL": "SOLUSDT",
    })
    orderbook_depth: int = 20

# ─────────────────────────────────────────────
# POLYMARKET API
# ─────────────────────────────────────────────
@dataclass
class PolymarketConfig:
    api_key: str = ""                # Set via env: POLYMARKET_API_KEY
    base_url: str = "https://clob.polymarket.com"
    gamma_url: str = "https://gamma-api.polymarket.com"
    # Market slugs for crypto price prediction (update periodically)
    market_slugs: dict = field(default_factory=lambda: {
        "BTC_UP_15M": "",  # Fill with actual market condition IDs
        "ETH_UP_15M": "",
        "SOL_UP_15M": "",
    })

# ─────────────────────────────────────────────
# GLOBAL CONFIG INSTANCE
# ─────────────────────────────────────────────
class Config:
    trading = TradingConfig()
    edge    = EdgeConfig()
    risk    = RiskConfig()
    ml      = MLConfig()
    binance = BinanceConfig()
    poly    = PolymarketConfig()

    # Logging
    log_dir: str = "logs"
    data_dir: str = "data"
    models_dir: str = "models"

cfg = Config()
