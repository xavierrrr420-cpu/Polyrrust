# 🤖 Polymarket Auto-Trading Bot

Bot prediksi arah harga crypto (BTC/ETH/SOL) untuk Polymarket prediction market, menggunakan pendekatan **hybrid ML + edge-based** untuk entry yang selektif dan profit-oriented.

---

## 📁 Struktur Project

```
polymarket_bot/
├── main.py                  # Entry point
├── config.py                # Semua parameter konfigurasi
├── data_fetcher.py          # Binance API + Technical Indicators
├── ml_model.py              # XGBoost / RF / Ensemble model
├── polymarket_client.py     # Polymarket CLOB API client
├── edge_risk_position.py    # Edge calc + Risk mgmt + Position tracker
├── bot.py                   # Main bot orchestrator
├── backtester.py            # Walk-forward backtesting
├── trade_logger.py          # CSV + console logging
├── requirements.txt
├── .env.example
├── models/                  # Saved model files (.pkl)
├── logs/                    # Trade logs (CSV + .log)
└── data/                    # Historical data cache
```

---

## ⚙️ Instalasi

```bash
# 1. Clone / extract project
cd polymarket_bot

# 2. Install dependencies
pip install -r requirements.txt

# 3. Setup API keys
cp .env.example .env
nano .env   # Isi BINANCE_API_KEY, POLYMARKET_API_KEY, dll.
```

---

## 🔑 API Keys yang Dibutuhkan

| Service    | Kegunaan                   | Link                              |
|------------|----------------------------|-----------------------------------|
| Binance    | Data OHLCV 15m             | https://www.binance.com/en/my/settings/api-management |
| Polymarket | Baca harga + place order   | https://docs.polymarket.com/       |

> **Penting:** Untuk Binance, cukup read-only key (tidak perlu trading permission).
> Polymarket API key dibutuhkan hanya untuk live trading. Paper trading tidak perlu key.

---

## 🚀 Cara Menjalankan

### 1. Backtest dulu (WAJIB sebelum live)
```bash
python main.py --backtest
```

### 2. Train model saja
```bash
python main.py --train
```

### 3. Paper trading (simulasi, tidak ada order nyata)
```bash
python main.py --paper
```

### 4. Live trading
```bash
python main.py
```

---

## 🧠 Arsitektur Bot

```
[Binance OHLCV] ──► [Indicator Engine] ──► [Feature Engineering]
                                                    │
                                                    ▼
[Polymarket Price] ──────────────────► [Edge Calculator]
                                                    │
                                          EDGE >= 8%?
                                          Confidence > 60%?
                                          Regime OK?
                                                    │
                                             YES ──► [Place Order]
                                                         │
                                                    [Position Manager]
                                                         │
                                              TP/SL/Time/Model Exit
                                                         │
                                                    [Risk Manager]
                                                    [Trade Logger]
```

---

## 📊 Parameter Utama

| Parameter              | Value       |
|------------------------|-------------|
| Timeframe              | 15 menit    |
| Assets                 | BTC, ETH, SOL |
| Min Edge               | 8%          |
| Min Confidence         | 60%         |
| Min Bet                | $1.20       |
| Max Bet                | $2.00       |
| Take Profit            | +50%        |
| Stop Loss              | -30%        |
| Max Open Positions     | 3           |
| Max Daily Loss         | $10         |
| Max Consecutive Loss   | 3x → pause  |
| Cooldown               | 10 menit    |
| Min Winrate (20 trade) | 40%         |

---

## 🏷️ Fitur ML (24 features)

**Technical:** RSI-14, EMA cross (9/21), MACD histogram, Bollinger band position & width, ATR%, ADX  
**Price Action:** Body size, wick ratio, HH/LL, breakout detection  
**Momentum:** Price change 3/6/12 candle, EMA slope  
**Volume:** Volume spike vs MA, volume trend  
**Time:** Session (Asia/EU/US), weekday  

---

## 📈 Edge Calculation

```
Model_Prob = XGBoost P(up) untuk 15m ke depan
Market_Prob = Harga YES di Polymarket

EDGE = Model_Prob - Market_Prob

Entry hanya jika EDGE >= 0.08 (8%)
```

---

## ⚠️ Polymarket Market IDs

Polymarket memakai **condition ID** (hex string) untuk setiap market. Kamu perlu mencari market yang aktif untuk prediksi 15m BTC/ETH/SOL:

1. Buka https://polymarket.com
2. Search "BTC price 15 minutes" atau "will BTC be higher"
3. Copy condition ID dari URL atau API
4. Masukkan ke `.env` sebagai `POLY_MARKET_BTC=0x...`

> **Catatan:** Market baru muncul setiap periode. Bot akan auto-search jika ID tidak dikonfigurasi, tapi akurasinya lebih baik jika ID di-hardcode.

---

## 🧯 Risk Management

- **Max daily loss $10** → bot pause otomatis
- **3 consecutive loss** → cooldown 10 menit
- **Winrate < 40% dalam 20 trade** → bot pause
- **Max 3 posisi open** secara bersamaan
- **Time exit 30 menit** jika belum hit TP/SL

---

## 📤 Output Trade Log

Setiap trade dicatat di `logs/trades_YYYYMMDD.csv`:

```
timestamp | event | trade_id | asset | direction | model_prob | market_prob | edge_pct | confidence | bet_size | entry_price | exit_price | pnl_usdc | pnl_pct | exit_reason | entry_reason | regime
```

---

## ⚡ Tips Optimasi

1. **Jalankan backtest dulu** dengan minimal 500 candle data historis
2. **Paper trade 1-2 minggu** sebelum live
3. **Monitor winrate** — jika < 45% setelah 50 trade, review edge threshold
4. **Retrain model** setiap 24 jam (sudah otomatis)
5. **Hindari weekend** — likuiditas Polymarket lebih rendah
6. **Cek market aktif** secara berkala — Polymarket market punya expiry

---

## ⚠️ Disclaimer

Bot ini untuk **edukasi dan riset**. Prediction market mengandung risiko tinggi. Polymarket outcome **tidak identik** dengan pergerakan harga Binance — ada faktor oracle, timing, dan market microstructure. **WAJIB backtest** sebelum trading dengan uang nyata.
