"""
notifier.py — Multi-channel notification system.
Supports: Telegram bot, console (rich), desktop (optional).

Setup Telegram:
  1. Chat @BotFather → /newbot → copy token
  2. Get your chat_id: https://api.telegram.org/bot<TOKEN>/getUpdates
  3. Add to .env: TELEGRAM_BOT_TOKEN=... TELEGRAM_CHAT_ID=...
"""

import os
import logging
import requests
from typing import Optional, TYPE_CHECKING
from colorama import Fore, Style, init as colorama_init

if TYPE_CHECKING:
    from edge_risk_position import Position

colorama_init(autoreset=True)
logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────
# CONSOLE PRINTER (colorized)
# ─────────────────────────────────────────────────────────────
class ConsoleNotifier:
    ICONS = {
        "entry":   "🟢",
        "exit_tp": "✅",
        "exit_sl": "❌",
        "exit_tm": "⏱️",
        "exit_md": "🔄",
        "risk":    "🚨",
        "info":    "ℹ️",
        "warn":    "⚠️",
        "train":   "🧠",
        "start":   "🚀",
    }

    def notify_entry(self, pos: "Position"):
        icon  = self.ICONS["entry"]
        edge  = f"{pos.edge*100:+.1f}%"
        conf  = f"{pos.confidence*100:.0f}%"
        color = Fore.GREEN if pos.direction == "YES" else Fore.CYAN
        print(
            f"\n{icon} {color}[ENTRY]{Style.RESET_ALL} "
            f"{pos.asset} {pos.direction:<3} | "
            f"${pos.bet_size:.2f} | "
            f"edge={Fore.YELLOW}{edge}{Style.RESET_ALL} | "
            f"conf={conf} | {pos.entry_reason}"
        )

    def notify_exit(self, pos: "Position"):
        won   = pos.pnl > 0
        icon  = self.ICONS["exit_tp"] if won else self.ICONS["exit_sl"]
        color = Fore.GREEN if won else Fore.RED
        pnl_s = f"{pos.pnl:+.2f}"
        pct_s = f"{pos.pnl_pct*100:+.1f}%"
        print(
            f"\n{icon} {color}[{pos.status.upper()}]{Style.RESET_ALL} "
            f"{pos.asset} {pos.direction:<3} | "
            f"pnl={color}{pnl_s}{Style.RESET_ALL} ({pct_s})"
        )

    def notify_risk(self, event: str, detail: str = ""):
        print(f"\n{self.ICONS['risk']} {Fore.RED}[RISK]{Style.RESET_ALL} {event} {detail}")

    def notify_info(self, msg: str):
        print(f"\n{self.ICONS['info']} {Fore.CYAN}[INFO]{Style.RESET_ALL} {msg}")

    def notify_train(self, asset: str, metrics: dict):
        acc = metrics.get("cv_accuracy_mean", 0)
        n   = metrics.get("samples", 0)
        print(
            f"\n{self.ICONS['train']} {Fore.MAGENTA}[TRAIN]{Style.RESET_ALL} "
            f"{asset} | samples={n} | cv_acc={acc:.1%}"
        )


# ─────────────────────────────────────────────────────────────
# TELEGRAM NOTIFIER
# ─────────────────────────────────────────────────────────────
class TelegramNotifier:
    def __init__(self):
        self.token   = os.getenv("TELEGRAM_BOT_TOKEN", "")
        self.chat_id = os.getenv("TELEGRAM_CHAT_ID", "")
        self.enabled = bool(self.token and self.chat_id)
        if not self.enabled:
            logger.debug("Telegram notifications disabled (no token/chat_id)")

    def send(self, text: str, parse_mode: str = "HTML"):
        if not self.enabled:
            return
        try:
            url = f"https://api.telegram.org/bot{self.token}/sendMessage"
            resp = requests.post(
                url,
                json={"chat_id": self.chat_id, "text": text, "parse_mode": parse_mode},
                timeout=10,
            )
            if not resp.ok:
                logger.warning(f"Telegram send failed: {resp.status_code} {resp.text[:100]}")
        except Exception as e:
            logger.warning(f"Telegram error: {e}")

    def notify_entry(self, pos: "Position"):
        emoji = "🟢" if pos.direction == "YES" else "🔵"
        self.send(
            f"{emoji} <b>ENTRY — {pos.asset} {pos.direction}</b>\n"
            f"💵 Bet: <code>${pos.bet_size:.2f}</code>\n"
            f"📊 Edge: <code>{pos.edge*100:+.1f}%</code>  "
            f"Conf: <code>{pos.confidence*100:.0f}%</code>\n"
            f"📈 Model: <code>{pos.model_prob:.3f}</code>  "
            f"Market: <code>{pos.market_prob:.3f}</code>\n"
            f"🏷️ Reason: {pos.entry_reason}"
        )

    def notify_exit(self, pos: "Position"):
        emoji = "✅" if pos.pnl > 0 else "❌"
        self.send(
            f"{emoji} <b>EXIT — {pos.asset} {pos.direction}</b>\n"
            f"📋 Reason: <code>{pos.status}</code>\n"
            f"💰 PnL: <code>${pos.pnl:+.2f} ({pos.pnl_pct*100:+.1f}%)</code>"
        )

    def notify_risk(self, event: str, detail: str = ""):
        self.send(f"🚨 <b>RISK ALERT</b>\n{event}\n<i>{detail}</i>")

    def notify_daily_summary(self, stats: dict):
        trades  = stats.get("trades", 0)
        wr      = stats.get("winrate", 0)
        pnl     = stats.get("total_pnl", 0)
        emoji   = "📈" if pnl >= 0 else "📉"
        self.send(
            f"{emoji} <b>Daily Summary</b>\n"
            f"Trades: {trades}  |  WR: {wr:.1%}\n"
            f"Total PnL: <code>${pnl:+.2f}</code>"
        )

    def notify_train(self, asset: str, metrics: dict):
        acc = metrics.get("cv_accuracy_mean", 0)
        n   = metrics.get("samples", 0)
        self.send(
            f"🧠 <b>Model Retrained — {asset}</b>\n"
            f"Samples: {n}  |  CV Acc: {acc:.1%}"
        )

    def test_connection(self) -> bool:
        if not self.enabled:
            print("⚠️  Telegram not configured (TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID missing)")
            return False
        self.send("🤖 <b>Polymarket Bot connected!</b>\nNotifications active.")
        print("✅ Telegram notification sent successfully.")
        return True


# ─────────────────────────────────────────────────────────────
# UNIFIED NOTIFIER
# ─────────────────────────────────────────────────────────────
class Notifier:
    """
    Route all bot events through console + Telegram.
    Add more channels (Discord, Email) by following the same pattern.
    """

    def __init__(self):
        self.console  = ConsoleNotifier()
        self.telegram = TelegramNotifier()

    def on_entry(self, pos: "Position"):
        self.console.notify_entry(pos)
        self.telegram.notify_entry(pos)

    def on_exit(self, pos: "Position"):
        self.console.notify_exit(pos)
        self.telegram.notify_exit(pos)

    def on_risk(self, event: str, detail: str = ""):
        self.console.notify_risk(event, detail)
        self.telegram.notify_risk(event, detail)

    def on_train(self, asset: str, metrics: dict):
        self.console.notify_train(asset, metrics)
        self.telegram.notify_train(asset, metrics)

    def on_info(self, msg: str):
        self.console.notify_info(msg)

    def on_daily_summary(self, stats: dict):
        self.telegram.notify_daily_summary(stats)

    def test(self):
        self.telegram.test_connection()
