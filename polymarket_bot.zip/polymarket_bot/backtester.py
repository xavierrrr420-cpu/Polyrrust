"""
backtester.py — Walk-forward backtesting engine
"""

import time
import logging
import numpy as np
import pandas as pd
from typing import Dict, List
from config import cfg
from data_fetcher import DataPipeline
from ml_model import MLModel, build_labels, prepare_features, FEATURE_COLS
from edge_risk_position import EdgeCalculator, PositionManager, RiskManager, Position

logger = logging.getLogger(__name__)


class BacktestResult:
    def __init__(self):
        self.trades: List[dict] = []
        self.equity_curve: List[float] = []

    def add_trade(self, t: dict):
        self.trades.append(t)

    def summary(self) -> dict:
        if not self.trades:
            return {"error": "no trades"}
        pnls = [t["pnl"] for t in self.trades]
        wins = [p for p in pnls if p > 0]
        losses = [p for p in pnls if p <= 0]
        total = sum(pnls)
        win_rate = len(wins) / len(pnls)
        avg_win  = np.mean(wins)  if wins   else 0
        avg_loss = np.mean(losses) if losses else 0
        profit_factor = abs(sum(wins) / (sum(losses) + 1e-9))
        max_drawdown = self._max_drawdown()

        return {
            "total_trades":    len(self.trades),
            "win_rate":        f"{win_rate:.1%}",
            "total_pnl":       f"${total:.2f}",
            "avg_win":         f"${avg_win:.2f}",
            "avg_loss":        f"${avg_loss:.2f}",
            "profit_factor":   f"{profit_factor:.2f}",
            "max_drawdown":    f"${max_drawdown:.2f}",
            "sharpe_approx":   f"{self._sharpe():.2f}",
        }

    def _max_drawdown(self) -> float:
        if not self.equity_curve:
            return 0
        eq = np.array(self.equity_curve)
        peak = np.maximum.accumulate(eq)
        dd = peak - eq
        return float(dd.max())

    def _sharpe(self) -> float:
        if len(self.trades) < 2:
            return 0
        pnls = np.array([t["pnl"] for t in self.trades])
        return float(pnls.mean() / (pnls.std() + 1e-9)) * np.sqrt(252)


class Backtester:
    """
    Walk-forward backtest:
    1. Train model on first N candles
    2. Test on next M candles
    3. Roll forward
    """

    def __init__(self, asset: str, train_size: int = 300, test_size: int = 100):
        self.asset      = asset
        self.train_size = train_size
        self.test_size  = test_size
        self.pipeline   = DataPipeline()
        self.edge_calc  = EdgeCalculator()

    def run(self, df: pd.DataFrame = None, min_edge: float = None) -> BacktestResult:
        if min_edge:
            self.edge_calc.min_edge = min_edge

        if df is None:
            logger.info(f"[BT] Fetching data for {self.asset}...")
            df = self.pipeline.get_enriched_data(self.asset, limit=500)

        if df.empty or len(df) < self.train_size + self.test_size:
            logger.error(f"[BT] Not enough data: {len(df)} rows")
            return BacktestResult()

        result   = BacktestResult()
        equity   = 0.0
        n        = len(df)
        windows  = range(self.train_size, n - self.test_size, self.test_size // 2)

        for start in windows:
            train_df = df.iloc[:start].copy()
            test_df  = df.iloc[start : start + self.test_size].copy()

            # Train model
            model = MLModel(self.asset)
            metrics = model.train(train_df)
            if metrics.get("status") != "trained":
                continue

            # Simulate on test window
            for i in range(1, len(test_df)):
                row_df   = test_df.iloc[:i+1].copy()
                last_row = row_df.iloc[-1]

                try:
                    p_up, confidence = model.predict_proba(row_df)
                except Exception:
                    continue

                # Simulate market price (random ±5% around model prob)
                simulated_market_prob = p_up + np.random.uniform(-0.08, 0.08)
                simulated_market_prob = np.clip(simulated_market_prob, 0.05, 0.95)

                mock_market = {"yes": simulated_market_prob}
                mock_ob     = {
                    "spread": 0.02,
                    "total_liquidity": 1000,
                    "best_bid": simulated_market_prob - 0.01,
                    "best_ask": simulated_market_prob + 0.01,
                }
                regime = "trending"   # simplified for backtest

                edge_result = self.edge_calc.calculate(
                    self.asset, p_up, confidence,
                    mock_market, mock_ob, regime
                )

                if not edge_result.should_enter:
                    continue

                # Simulate outcome: use actual next candle close direction
                if i + 1 < len(test_df):
                    actual_up = test_df.iloc[i+1]["close"] > last_row["close"]
                    won = (edge_result.direction == "YES" and actual_up) or \
                          (edge_result.direction == "NO"  and not actual_up)

                    pnl_pct = cfg.trading.take_profit if won else cfg.trading.stop_loss
                    pnl     = edge_result.bet_size * pnl_pct
                    equity += pnl

                    result.add_trade({
                        "asset":      self.asset,
                        "direction":  edge_result.direction,
                        "model_prob": p_up,
                        "edge":       edge_result.edge,
                        "confidence": confidence,
                        "bet_size":   edge_result.bet_size,
                        "won":        won,
                        "pnl":        pnl,
                        "equity":     equity,
                    })
                    result.equity_curve.append(equity)

        return result

    def parameter_sweep(self, df: pd.DataFrame, edges: list, confidences: list) -> pd.DataFrame:
        """Grid search over edge and confidence thresholds."""
        rows = []
        for e in edges:
            for c in confidences:
                self.edge_calc.min_edge       = e
                self.edge_calc.min_confidence = c
                bt = self.run(df=df)
                summary = bt.summary()
                summary["min_edge"]       = e
                summary["min_confidence"] = c
                rows.append(summary)
        return pd.DataFrame(rows)


def run_full_backtest():
    """CLI entry point for backtesting all assets."""
    import json
    pipeline = DataPipeline()
    results  = {}

    for asset in cfg.trading.assets:
        logger.info(f"\n{'='*50}")
        logger.info(f"Backtesting {asset}...")
        df = pipeline.get_enriched_data(asset, limit=500)
        bt = Backtester(asset)
        result = bt.run(df)
        summary = result.summary()
        results[asset] = summary
        print(f"\n[{asset}] Backtest Results:")
        for k, v in summary.items():
            print(f"  {k:<20} {v}")

    print("\n\nFull Backtest Summary:")
    print(json.dumps(results, indent=2))
    return results


if __name__ == "__main__":
    from trade_logger import setup_logging
    setup_logging(logging.INFO)
    run_full_backtest()
