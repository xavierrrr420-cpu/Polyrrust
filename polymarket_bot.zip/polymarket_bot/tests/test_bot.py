"""
tests/test_bot.py — Unit tests for all bot modules
Run: python -m pytest tests/ -v
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import time
import numpy as np
import pandas as pd
import pytest

from config import cfg
from data_fetcher import IndicatorEngine
from ml_model import (
    MLModel, build_labels, prepare_features,
    FEATURE_COLS, ModelRegistry
)
from edge_risk_position import (
    EdgeCalculator, EdgeResult,
    PositionManager, Position,
    RiskManager
)


# ─────────────────────────────────────────────────────────────
# FIXTURES
# ─────────────────────────────────────────────────────────────
def make_synthetic_df(n: int = 600, seed: int = 42) -> pd.DataFrame:
    np.random.seed(seed)
    idx    = pd.date_range("2024-01-01", periods=n, freq="15min")
    close  = np.cumsum(np.random.randn(n) * 0.5) + 100
    spread = np.abs(np.random.randn(n) * 0.3)
    df = pd.DataFrame({
        "open":   close - spread / 2,
        "high":   close + spread,
        "low":    close - spread,
        "close":  close,
        "volume": np.random.exponential(1000, n),
        "trades": np.random.randint(50, 500, n),
    }, index=idx)
    return df


@pytest.fixture
def raw_df():
    return make_synthetic_df(600)


@pytest.fixture
def enriched_df(raw_df):
    ie = IndicatorEngine()
    return ie.compute_all(raw_df.copy())


@pytest.fixture
def trained_model(enriched_df):
    m = MLModel("BTC")
    metrics = m.train(enriched_df)
    assert metrics["status"] == "trained", f"Train failed: {metrics}"
    return m


# ─────────────────────────────────────────────────────────────
# INDICATOR ENGINE
# ─────────────────────────────────────────────────────────────
class TestIndicatorEngine:
    def test_compute_all_returns_dataframe(self, raw_df):
        ie = IndicatorEngine()
        df = ie.compute_all(raw_df.copy())
        assert isinstance(df, pd.DataFrame)
        assert len(df) > 100

    def test_expected_columns_present(self, enriched_df):
        required = [
            "rsi_14", "ema_9", "ema_21", "ema_50",
            "macd", "macd_signal", "macd_hist",
            "bb_upper", "bb_lower", "bb_position",
            "atr_14", "adx_14",
            "vol_spike", "vol_trend",
            "body_size", "upper_wick", "lower_wick",
            "breakout_up", "breakout_down",
            "hh", "ll", "session", "weekday",
        ]
        for col in required:
            assert col in enriched_df.columns, f"Missing column: {col}"

    def test_rsi_range(self, enriched_df):
        rsi = enriched_df["rsi_14"].dropna()
        assert rsi.between(0, 100).all(), "RSI out of [0, 100] range"

    def test_bb_position_range(self, enriched_df):
        pos = enriched_df["bb_position"].dropna()
        # Typically between -0.2 and 1.2 (can exceed slightly on extremes)
        assert pos.between(-1, 2).all()

    def test_ema_cross_values(self, enriched_df):
        assert set(enriched_df["ema_cross_9_21"].unique()).issubset({-1, 1})

    def test_session_values(self, enriched_df):
        assert set(enriched_df["session"].unique()).issubset({0, 1, 2})

    def test_no_all_nan_columns(self, enriched_df):
        for col in FEATURE_COLS:
            if col in enriched_df.columns:
                assert not enriched_df[col].isna().all(), f"{col} is all NaN"


# ─────────────────────────────────────────────────────────────
# ML MODEL
# ─────────────────────────────────────────────────────────────
class TestMLModel:
    def test_train_returns_metrics(self, enriched_df):
        m = MLModel("ETH")
        metrics = m.train(enriched_df)
        assert metrics["status"] == "trained"
        assert metrics["samples"] > 0
        assert "cv_accuracy_mean" in metrics

    def test_predict_proba_range(self, trained_model, enriched_df):
        p_up, conf = trained_model.predict_proba(enriched_df)
        assert 0.0 <= p_up <= 1.0, f"p_up={p_up} out of range"
        assert 0.0 <= conf <= 1.0, f"conf={conf} out of range"

    def test_confidence_formula(self, trained_model, enriched_df):
        p_up, conf = trained_model.predict_proba(enriched_df)
        expected_conf = abs(p_up - 0.5) * 2.0
        assert abs(conf - expected_conf) < 1e-6

    def test_model_trains_with_min_data(self):
        m = MLModel("SOL")
        df = make_synthetic_df(n=50)   # Below min_train_samples
        ie = IndicatorEngine()
        df = ie.compute_all(df)
        metrics = m.train(df)
        assert metrics["status"] == "insufficient_data"

    def test_labels_binary(self, enriched_df):
        labels = build_labels(enriched_df)
        assert set(labels.dropna().unique()).issubset({0, 1})

    def test_feature_cols_count(self):
        assert len(FEATURE_COLS) >= 20

    def test_save_and_load(self, trained_model, enriched_df, tmp_path):
        import pickle
        cfg.models_dir = str(tmp_path)
        trained_model.model_path = str(tmp_path / "BTC_test.pkl")
        trained_model.save()
        assert os.path.exists(trained_model.model_path)

        m2 = MLModel("BTC")
        m2.model_path = trained_model.model_path
        loaded = m2.load()
        assert loaded
        p1, _ = trained_model.predict_proba(enriched_df)
        p2, _ = m2.predict_proba(enriched_df)
        assert abs(p1 - p2) < 1e-6

    def test_registry_creates_models_for_all_assets(self):
        reg = ModelRegistry()
        for asset in cfg.trading.assets:
            assert asset in reg.models
            assert isinstance(reg.get(asset), MLModel)


# ─────────────────────────────────────────────────────────────
# EDGE CALCULATOR
# ─────────────────────────────────────────────────────────────
class TestEdgeCalculator:
    def setup_method(self):
        self.ec = EdgeCalculator()

    def _make_result(self, p_up, market_yes, edge=None, conf=0.70,
                     spread=0.02, liquidity=1000, regime="trending"):
        return self.ec.calculate(
            "BTC", p_up, conf,
            {"yes": market_yes},
            {"spread": spread, "total_liquidity": liquidity,
             "best_bid": market_yes - spread/2,
             "best_ask": market_yes + spread/2},
            regime,
        )

    def test_yes_direction_when_p_up_high(self):
        r = self._make_result(p_up=0.75, market_yes=0.55)
        assert r.direction == "YES"

    def test_no_direction_when_p_up_low(self):
        r = self._make_result(p_up=0.30, market_yes=0.55)
        assert r.direction == "NO"

    def test_enter_when_edge_high_enough(self):
        r = self._make_result(p_up=0.75, market_yes=0.55)
        assert r.should_enter is True

    def test_reject_when_edge_too_low(self):
        r = self._make_result(p_up=0.60, market_yes=0.57)
        assert r.should_enter is False
        assert "edge" in r.reject_reason.lower()

    def test_reject_when_confidence_low(self):
        r = self._make_result(p_up=0.80, market_yes=0.50, conf=0.50)
        assert r.should_enter is False
        assert "confidence" in r.reject_reason.lower()

    def test_reject_when_spread_high(self):
        r = self._make_result(p_up=0.80, market_yes=0.50, spread=0.20)
        assert r.should_enter is False
        assert "spread" in r.reject_reason.lower()

    def test_reject_in_sideways_regime(self):
        r = self._make_result(p_up=0.80, market_yes=0.50, regime="sideways")
        assert r.should_enter is False
        assert "sideways" in r.reject_reason.lower()

    def test_reject_low_liquidity(self):
        r = self._make_result(p_up=0.80, market_yes=0.50, liquidity=100)
        assert r.should_enter is False
        assert "liquidity" in r.reject_reason.lower()

    def test_bet_size_within_bounds(self):
        r = self._make_result(p_up=0.80, market_yes=0.50, conf=0.90)
        assert cfg.trading.min_bet <= r.bet_size <= cfg.trading.max_bet

    def test_bet_size_scales_with_confidence(self):
        r_low  = self._make_result(p_up=0.75, market_yes=0.50, conf=0.60)
        r_high = self._make_result(p_up=0.75, market_yes=0.50, conf=0.99)
        assert r_high.bet_size >= r_low.bet_size

    def test_edge_calculation_accuracy(self):
        r = self._make_result(p_up=0.72, market_yes=0.55)
        expected_edge = 0.72 - 0.55
        assert abs(r.edge - expected_edge) < 1e-4


# ─────────────────────────────────────────────────────────────
# POSITION MANAGER
# ─────────────────────────────────────────────────────────────
class TestPositionManager:
    def _make_pos(self, asset="BTC", direction="YES", entry=0.60, bet=1.50) -> Position:
        return Position(
            id="POS_0001", asset=asset, direction=direction,
            entry_price=entry, entry_time=time.time() - 60,
            bet_size=bet, token_id="0xABC", order_id="ORD123",
            model_prob=0.70, market_prob=0.60, edge=0.10,
            confidence=0.75, entry_reason="test",
        )

    def test_can_open_initially(self):
        pm = PositionManager()
        assert pm.can_open()

    def test_cannot_open_when_max_reached(self):
        pm = PositionManager()
        for i in range(cfg.trading.max_open_positions):
            pos = self._make_pos()
            pos.id = f"POS_{i:04d}"
            pm.add(pos)
        assert not pm.can_open()

    def test_tp_triggered(self):
        pm = PositionManager()
        pos = self._make_pos(entry=0.60)
        pm.add(pos)
        # YES: current > entry by 50%+
        current = 0.60 * (1 + cfg.trading.take_profit + 0.01)
        reason = pm.should_exit(pos, current, 0.70, 0.75)
        assert reason == "closed_tp"

    def test_sl_triggered(self):
        pm = PositionManager()
        pos = self._make_pos(entry=0.60)
        pm.add(pos)
        current = 0.60 * (1 + cfg.trading.stop_loss - 0.01)
        reason = pm.should_exit(pos, current, 0.70, 0.75)
        assert reason == "closed_sl"

    def test_time_exit(self):
        pm = PositionManager()
        pos = self._make_pos(entry=0.60)
        pos.entry_time = time.time() - (cfg.trading.time_exit_minutes + 5) * 60
        reason = pm.should_exit(pos, 0.61, 0.70, 0.75)
        assert reason == "closed_time"

    def test_model_exit_direction_flip(self):
        pm = PositionManager()
        pos = self._make_pos(direction="YES", entry=0.60)
        pm.add(pos)
        # Model now says strong down
        reason = pm.should_exit(pos, 0.61, model_prob=0.30, confidence=0.80)
        assert reason == "closed_model"

    def test_stats_empty(self):
        pm = PositionManager()
        stats = pm.get_stats()
        assert stats.get("trades", 0) == 0

    def test_stats_after_trades(self):
        pm = PositionManager()
        pos = self._make_pos()
        pm.add(pos)
        pm.close(pos, 0.90, "closed_tp")   # big win
        stats = pm.get_stats()
        assert stats["trades"] == 1
        assert stats["wins"]   == 1
        assert stats["winrate"] == 1.0
        assert stats["total_pnl"] > 0


# ─────────────────────────────────────────────────────────────
# RISK MANAGER
# ─────────────────────────────────────────────────────────────
class TestRiskManager:
    def test_trading_allowed_initially(self):
        rm = RiskManager()
        allowed, _ = rm.is_trading_allowed()
        assert allowed

    def test_pause_on_max_daily_loss(self):
        rm = RiskManager()
        rm.record_trade(-cfg.risk.max_daily_loss - 0.01)
        allowed, reason = rm.is_trading_allowed()
        assert not allowed
        assert "daily" in reason.lower()

    def test_cooldown_on_consecutive_loss(self):
        rm = RiskManager()
        for _ in range(cfg.risk.max_consecutive_loss):
            rm.record_trade(-0.50)
        # Should be in cooldown
        allowed, reason = rm.is_trading_allowed()
        if not allowed:
            assert "cooldown" in reason.lower()

    def test_win_resets_consecutive_loss(self):
        rm = RiskManager()
        rm.record_trade(-0.50)
        rm.record_trade(-0.50)
        rm.record_trade(+1.00)   # win
        assert rm.consecutive_loss == 0

    def test_winrate_check_passes_with_few_trades(self):
        pm = PositionManager()
        rm = RiskManager()
        # Less than min window → should pass
        result = rm.check_winrate(pm)
        assert result is True

    def test_winrate_check_fails_below_threshold(self):
        pm = PositionManager()
        rm = RiskManager()
        # Manufacture 20 losing trades
        for i in range(cfg.risk.min_winrate_window):
            pos = Position(
                id=f"P{i}", asset="BTC", direction="YES",
                entry_price=0.6, entry_time=time.time() - 100,
                bet_size=1.5, token_id="x", order_id="o",
                model_prob=0.7, market_prob=0.6, edge=0.1,
                confidence=0.7, entry_reason="test",
                status="closed_sl", pnl=-0.45, pnl_pct=-0.30,
            )
            pm.positions.append(pos)
        result = rm.check_winrate(pm)
        assert result is False

    def test_resume_clears_pause(self):
        rm = RiskManager()
        rm.paused = True
        rm.resume()
        allowed, _ = rm.is_trading_allowed()
        assert allowed


# ─────────────────────────────────────────────────────────────
# INTEGRATION: FULL PIPELINE
# ─────────────────────────────────────────────────────────────
class TestIntegration:
    def test_full_predict_pipeline(self):
        """Train → predict → edge → entry decision."""
        ie  = IndicatorEngine()
        df  = ie.compute_all(make_synthetic_df(700))
        m   = MLModel("BTC")
        m.train(df)
        p_up, conf = m.predict_proba(df)

        ec = EdgeCalculator()
        result = ec.calculate(
            "BTC", p_up, conf,
            {"yes": 0.50},
            {"spread": 0.02, "total_liquidity": 800},
            "trending",
        )
        assert isinstance(result, EdgeResult)
        assert 0 <= result.edge <= 1
        assert isinstance(result.should_enter, bool)

    def test_position_full_lifecycle(self):
        """Open → monitor → close → stats."""
        pm = PositionManager()
        rm = RiskManager()
        pos = Position(
            id=pm.next_id(), asset="ETH", direction="YES",
            entry_price=0.55, entry_time=time.time() - 60,
            bet_size=1.60, token_id="0xTEST", order_id="ORD999",
            model_prob=0.72, market_prob=0.55, edge=0.17,
            confidence=0.80, entry_reason="integration_test",
        )
        pm.add(pos)
        assert pm.open_count() == 1

        # Simulate TP hit
        tp_price = 0.55 * (1 + cfg.trading.take_profit + 0.05)
        reason = pm.should_exit(pos, tp_price, 0.72, 0.80)
        assert reason == "closed_tp"
        pm.close(pos, tp_price, reason)
        rm.record_trade(pos.pnl)

        assert pm.open_count() == 0
        assert pos.pnl > 0
        assert rm.consecutive_loss == 0
