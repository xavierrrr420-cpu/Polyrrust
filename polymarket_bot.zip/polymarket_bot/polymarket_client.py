"""
polymarket_client.py — Interact with Polymarket CLOB API
Docs: https://docs.polymarket.com/
"""

import time
import hmac
import hashlib
import logging
import requests
from typing import Optional
from config import cfg

logger = logging.getLogger(__name__)


class PolymarketClient:
    """
    Client for Polymarket's CLOB (Central Limit Order Book).
    Supports: market lookup, price fetching, order placement, position management.
    """

    def __init__(self):
        self.clob_url  = cfg.poly.base_url
        self.gamma_url = cfg.poly.gamma_url
        self.api_key   = cfg.poly.api_key
        self.session   = requests.Session()
        self.session.headers.update({
            "Content-Type": "application/json",
            "POLY_API_KEY": self.api_key,
        })

    # ── MARKET DATA ───────────────────────────────────────────

    def get_markets(self, keyword: str = "") -> list:
        """Search Gamma API for markets matching keyword."""
        try:
            params = {"active": "true", "closed": "false"}
            if keyword:
                params["search"] = keyword
            resp = self.session.get(f"{self.gamma_url}/markets", params=params, timeout=10)
            resp.raise_for_status()
            return resp.json().get("markets", [])
        except Exception as e:
            logger.error(f"get_markets error: {e}")
            return []

    def find_crypto_market(self, asset: str, direction: str = "up") -> Optional[dict]:
        """
        Find the most relevant 15m price prediction market for a crypto asset.
        Returns market dict or None.
        """
        keywords = [f"{asset} price", f"will {asset}", f"{asset} higher"]
        markets = []
        for kw in keywords:
            markets += self.get_markets(kw)
        
        # Filter by relevance
        asset_markets = [
            m for m in markets
            if asset.lower() in m.get("question", "").lower()
            and not m.get("closed", True)
        ]
        if not asset_markets:
            return None

        # Sort by volume descending
        asset_markets.sort(key=lambda m: float(m.get("volume", 0)), reverse=True)
        return asset_markets[0]

    def get_market_price(self, condition_id: str) -> Optional[dict]:
        """
        Get current YES/NO prices for a market.
        Returns {"yes": float, "no": float, "spread": float, "liquidity": float}
        """
        try:
            resp = self.session.get(
                f"{self.clob_url}/price",
                params={"token_id": condition_id, "side": "BUY"},
                timeout=10,
            )
            resp.raise_for_status()
            data = resp.json()

            yes_price = float(data.get("price", 0))
            no_price  = round(1.0 - yes_price, 4)
            spread    = abs(yes_price - no_price)

            return {
                "yes": yes_price,
                "no":  no_price,
                "spread": spread,
                "raw": data,
            }
        except Exception as e:
            logger.error(f"get_market_price error [{condition_id}]: {e}")
            return None

    def get_orderbook_summary(self, token_id: str) -> dict:
        """Fetch orderbook to estimate liquidity and spread."""
        try:
            resp = self.session.get(
                f"{self.clob_url}/book",
                params={"token_id": token_id},
                timeout=10,
            )
            resp.raise_for_status()
            book = resp.json()
            bids = book.get("bids", [])
            asks = book.get("asks", [])

            bid_liq = sum(float(b["size"]) for b in bids[:5])
            ask_liq = sum(float(a["size"]) for a in asks[:5])

            best_bid = float(bids[0]["price"]) if bids else 0
            best_ask = float(asks[0]["price"]) if asks else 1
            spread   = best_ask - best_bid

            return {
                "bid_liquidity": bid_liq,
                "ask_liquidity": ask_liq,
                "total_liquidity": bid_liq + ask_liq,
                "best_bid": best_bid,
                "best_ask": best_ask,
                "spread": spread,
            }
        except Exception as e:
            logger.warning(f"Orderbook summary error: {e}")
            return {}

    # ── TRADING ───────────────────────────────────────────────

    def place_market_order(
        self,
        token_id: str,
        side: str,        # "BUY" or "SELL"
        amount_usdc: float,
        direction: str,   # "YES" or "NO"
    ) -> Optional[dict]:
        """
        Place a market order on Polymarket CLOB.
        amount_usdc = amount to spend in USDC.
        """
        if not self.api_key:
            logger.warning("No Polymarket API key configured. PAPER TRADE mode.")
            return self._paper_trade(token_id, side, amount_usdc, direction)

        try:
            payload = {
                "token_id": token_id,
                "side": side,
                "amount": str(amount_usdc),
                "order_type": "MARKET",
            }
            resp = self.session.post(
                f"{self.clob_url}/order",
                json=payload,
                timeout=15,
            )
            resp.raise_for_status()
            result = resp.json()
            logger.info(f"Order placed: {direction} | ${amount_usdc:.2f} | order_id={result.get('orderID')}")
            return result
        except Exception as e:
            logger.error(f"place_market_order error: {e}")
            return None

    def _paper_trade(self, token_id, side, amount, direction) -> dict:
        """Simulate order in paper-trade mode."""
        import uuid
        return {
            "orderID": str(uuid.uuid4()),
            "paper_trade": True,
            "token_id": token_id,
            "side": side,
            "amount": amount,
            "direction": direction,
            "status": "MATCHED",
        }

    def cancel_order(self, order_id: str) -> bool:
        try:
            resp = self.session.delete(
                f"{self.clob_url}/order/{order_id}",
                timeout=10,
            )
            return resp.status_code == 200
        except Exception as e:
            logger.error(f"cancel_order error: {e}")
            return False

    def get_positions(self) -> list:
        """Fetch open positions."""
        try:
            resp = self.session.get(f"{self.clob_url}/positions", timeout=10)
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            logger.error(f"get_positions error: {e}")
            return []
