"""
data_fetcher.py — Fetch OHLCV from Binance + compute technical indicators
"""

import time
import logging
import numpy as np
import pandas as pd
import requests
from typing import Optional
from config import cfg

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────
# BINANCE CLIENT
# ─────────────────────────────────────────────────────────────
class BinanceClient:
    def __init__(self):
        self.base_url = cfg.binance.base_url
        self.symbol_map = cfg.binance.symbol_map
        self.session = requests.Session()
        self.session.headers.update({"X-MBX-APIKEY": cfg.binance.api_key})

    def get_klines(self, asset: str, interval: str = "15m", limit: int = 200) -> pd.DataFrame:
        """Fetch OHLCV candlestick data from Binance."""
        symbol = self.symbol_map.get(asset)
        if not symbol:
            raise ValueError(f"Unknown asset: {asset}")

        url = f"{self.base_url}/api/v3/klines"
        params = {"symbol": symbol, "interval": interval, "limit": limit}

        try:
            resp = self.session.get(url, params=params, timeout=10)
            resp.raise_for_status()
            raw = resp.json()
        except Exception as e:
            logger.error(f"Binance klines error [{asset}]: {e}")
            return pd.DataFrame()

        cols = [
            "open_time", "open", "high", "low", "close", "volume",
            "close_time", "quote_vol", "trades", "taker_buy_base",
            "taker_buy_quote", "ignore"
        ]
        df = pd.DataFrame(raw, columns=cols)
        df = df[["open_time", "open", "high", "low", "close", "volume", "trades"]].copy()

        for col in ["open", "high", "low", "close", "volume"]:
            df[col] = df[col].astype(float)
        df["trades"] = df["trades"].astype(int)
        df["open_time"] = pd.to_datetime(df["open_time"], unit="ms")
        df.set_index("open_time", inplace=True)

        return df

    def get_orderbook(self, asset: str, depth: int = 20) -> dict:
        """Fetch order book depth."""
        symbol = self.symbol_map.get(asset)
        url = f"{self.base_url}/api/v3/depth"
        params = {"symbol": symbol, "limit": depth}
        try:
            resp = self.session.get(url, params=params, timeout=10)
            resp.raise_for_status()
            ob = resp.json()
            bids = np.array(ob["bids"], dtype=float)
            asks = np.array(ob["asks"], dtype=float)
            bid_vol = bids[:, 1].sum()
            ask_vol = asks[:, 1].sum()
            imbalance = (bid_vol - ask_vol) / (bid_vol + ask_vol + 1e-9)
            return {
                "bid_vol": float(bid_vol),
                "ask_vol": float(ask_vol),
                "imbalance": float(imbalance),
                "best_bid": float(bids[0, 0]),
                "best_ask": float(asks[0, 0]),
                "spread": float(asks[0, 0] - bids[0, 0]),
            }
        except Exception as e:
            logger.warning(f"Orderbook fetch error [{asset}]: {e}")
            return {}


# ─────────────────────────────────────────────────────────────
# TECHNICAL INDICATORS
# ─────────────────────────────────────────────────────────────
class IndicatorEngine:
    """Compute all technical indicators from OHLCV DataFrame."""

    @staticmethod
    def ema(series: pd.Series, period: int) -> pd.Series:
        return series.ewm(span=period, adjust=False).mean()

    @staticmethod
    def rsi(close: pd.Series, period: int = 14) -> pd.Series:
        delta = close.diff()
        gain = delta.clip(lower=0)
        loss = -delta.clip(upper=0)
        avg_gain = gain.ewm(com=period - 1, adjust=False).mean()
        avg_loss = loss.ewm(com=period - 1, adjust=False).mean()
        rs = avg_gain / (avg_loss + 1e-9)
        return 100 - (100 / (1 + rs))

    @staticmethod
    def macd(close: pd.Series, fast=12, slow=26, signal=9):
        ema_fast = close.ewm(span=fast, adjust=False).mean()
        ema_slow = close.ewm(span=slow, adjust=False).mean()
        macd_line = ema_fast - ema_slow
        signal_line = macd_line.ewm(span=signal, adjust=False).mean()
        histogram = macd_line - signal_line
        return macd_line, signal_line, histogram

    @staticmethod
    def bollinger_bands(close: pd.Series, period: int = 20, std_dev: float = 2.0):
        middle = close.rolling(window=period).mean()
        std = close.rolling(window=period).std()
        upper = middle + std_dev * std
        lower = middle - std_dev * std
        return upper, middle, lower

    @staticmethod
    def atr(high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14) -> pd.Series:
        prev_close = close.shift(1)
        tr = pd.concat([
            high - low,
            (high - prev_close).abs(),
            (low - prev_close).abs()
        ], axis=1).max(axis=1)
        return tr.ewm(com=period - 1, adjust=False).mean()

    @staticmethod
    def adx(high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14) -> pd.Series:
        """Average Directional Index for trend strength."""
        plus_dm = high.diff()
        minus_dm = -low.diff()
        plus_dm[plus_dm < 0] = 0
        minus_dm[minus_dm < 0] = 0
        plus_dm[(plus_dm < minus_dm)] = 0
        minus_dm[(minus_dm < plus_dm)] = 0

        atr_val = IndicatorEngine.atr(high, low, close, period)
        plus_di = 100 * (plus_dm.ewm(com=period - 1, adjust=False).mean() / (atr_val + 1e-9))
        minus_di = 100 * (minus_dm.ewm(com=period - 1, adjust=False).mean() / (atr_val + 1e-9))
        dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di + 1e-9)
        return dx.ewm(com=period - 1, adjust=False).mean()

    @staticmethod
    def volume_ma(volume: pd.Series, period: int = 20) -> pd.Series:
        return volume.rolling(window=period).mean()

    def compute_all(self, df: pd.DataFrame) -> pd.DataFrame:
        """Add all indicators to DataFrame."""
        close = df["close"]
        high  = df["high"]
        low   = df["low"]
        vol   = df["volume"]

        # EMA
        df["ema_9"]  = self.ema(close, 9)
        df["ema_21"] = self.ema(close, 21)
        df["ema_50"] = self.ema(close, 50)

        # RSI
        df["rsi_14"] = self.rsi(close, 14)

        # MACD
        df["macd"], df["macd_signal"], df["macd_hist"] = self.macd(close)

        # Bollinger Bands
        df["bb_upper"], df["bb_mid"], df["bb_lower"] = self.bollinger_bands(close)
        df["bb_width"] = (df["bb_upper"] - df["bb_lower"]) / (df["bb_mid"] + 1e-9)
        df["bb_position"] = (close - df["bb_lower"]) / (df["bb_upper"] - df["bb_lower"] + 1e-9)

        # ATR
        df["atr_14"] = self.atr(high, low, close, 14)
        df["atr_pct"] = df["atr_14"] / (close + 1e-9)

        # ADX
        df["adx_14"] = self.adx(high, low, close, 14)

        # Volume
        df["vol_ma_20"] = self.volume_ma(vol, 20)
        df["vol_spike"] = vol / (df["vol_ma_20"] + 1e-9)
        df["vol_trend"] = vol.pct_change(5)

        # Price action
        df["body_size"] = (close - df["open"]).abs() / (high - low + 1e-9)
        df["upper_wick"] = (high - close.clip(lower=df["open"])) / (high - low + 1e-9)
        df["lower_wick"] = (close.clip(upper=df["open"]) - low) / (high - low + 1e-9)
        df["candle_dir"]  = np.sign(close - df["open"])

        # Higher high / lower low
        df["hh"] = (high > high.shift(1)).astype(int)
        df["ll"] = (low  < low.shift(1)).astype(int)

        # EMA cross signals
        df["ema_cross_9_21"] = np.where(df["ema_9"] > df["ema_21"], 1, -1)
        df["ema_slope_9"]    = df["ema_9"].pct_change(3)
        df["ema_slope_21"]   = df["ema_21"].pct_change(3)

        # Price momentum
        df["price_mom_3"]  = close.pct_change(3)
        df["price_mom_6"]  = close.pct_change(6)
        df["price_mom_12"] = close.pct_change(12)

        # Breakout: close vs last 10 highs/lows
        df["resist_10"] = high.rolling(10).max().shift(1)
        df["support_10"] = low.rolling(10).min().shift(1)
        df["breakout_up"]   = (close > df["resist_10"]).astype(int)
        df["breakout_down"] = (close < df["support_10"]).astype(int)

        # Time features (UTC)
        idx = df.index
        df["hour"] = idx.hour
        df["weekday"] = idx.weekday
        df["session"] = df["hour"].apply(self._get_session)

        return df.dropna()

    @staticmethod
    def _get_session(hour: int) -> int:
        """0=Asia, 1=EU, 2=US."""
        if 0 <= hour < 8:
            return 0
        elif 8 <= hour < 14:
            return 1
        else:
            return 2


# ─────────────────────────────────────────────────────────────
# DATA PIPELINE
# ─────────────────────────────────────────────────────────────
class DataPipeline:
    def __init__(self):
        self.binance = BinanceClient()
        self.indicators = IndicatorEngine()

    def get_enriched_data(self, asset: str, limit: int = 200) -> pd.DataFrame:
        """Full pipeline: fetch + enrich with indicators."""
        df = self.binance.get_klines(asset, interval=cfg.trading.timeframe, limit=limit)
        if df.empty:
            return df
        df = self.indicators.compute_all(df)
        return df

    def get_orderbook_features(self, asset: str) -> dict:
        return self.binance.get_orderbook(asset)

    def get_market_regime(self, df: pd.DataFrame) -> str:
        """Detect trending / sideways / high_volatility."""
        if df.empty:
            return "unknown"
        last = df.iloc[-1]
        adx = last.get("adx_14", 0)
        atr_pct = last.get("atr_pct", 0)
        if atr_pct > 0.025:
            return "high_volatility"
        if adx > 25:
            return "trending"
        return "sideways"
