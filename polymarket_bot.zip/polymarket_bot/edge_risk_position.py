"""
edge_calculator.py — Edge detection between ML model and Polymarket price
risk_manager.py    — Daily loss, consecutive loss, winrate enforcement
position_manager.py — Position lifecycle tracking
"""

import time
import logging
from dataclasses import dataclass, field
from typing import Optional, List, Dict
from config import cfg

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
#  EDGE CALCULATOR
# ═══════════════════════════════════════════════════════════════
@dataclass
class EdgeResult:
    asset: str
    direction: str          # "YES" or "NO"
    model_prob: float       # P(up) from ML
    market_prob: float      # YES price from Polymarket
    edge: float             # model_prob - market_prob
    confidence: float       # model confidence (0-1)
    bet_size: float         # calculated bet
    should_enter: bool
    reject_reason: str = ""


class EdgeCalculator:
    def __init__(self):
        self.min_edge       = cfg.edge.min_edge
        self.min_confidence = cfg.edge.min_confidence
        self.max_spread     = cfg.edge.max_spread
        self.min_liquidity  = cfg.edge.min_liquidity_usdc

    def calculate(
        self,
        asset: str,
        model_prob: float,
        confidence: float,
        market_data: dict,   # from polymarket_client.get_market_price
        ob_data: dict,       # from polymarket_client.get_orderbook_summary
        regime: str,
    ) -> EdgeResult:
        """
        Compute edge and decide whether to enter.
        Direction: if model_prob > 0.5 → bet YES, else bet NO.
        """
        yes_price = market_data.get("yes", 0.5)
        spread    = ob_data.get("spread", 1.0)
        liquidity = ob_data.get("total_liquidity", 0)

        # Determine direction
        if model_prob >= 0.5:
            direction    = "YES"
            market_prob  = yes_price
            edge         = model_prob - market_prob
        else:
            direction    = "NO"
            market_prob  = 1.0 - yes_price      # P(down) in market
            model_p_down = 1.0 - model_prob
            edge         = model_p_down - market_prob

        # Position sizing
        bet_size = cfg.trading.min_bet + (
            confidence * (cfg.trading.max_bet - cfg.trading.min_bet)
        )
        bet_size = round(min(max(bet_size, cfg.trading.min_bet), cfg.trading.max_bet), 2)

        # Entry checks
        should_enter, reason = self._check_entry(edge, confidence, spread, liquidity, regime)

        return EdgeResult(
            asset=asset,
            direction=direction,
            model_prob=model_prob,
            market_prob=market_prob,
            edge=round(edge, 4),
            confidence=round(confidence, 4),
            bet_size=bet_size,
            should_enter=should_enter,
            reject_reason=reason,
        )

    def _check_entry(
        self, edge, confidence, spread, liquidity, regime
    ) -> tuple:
        if edge < self.min_edge:
            return False, f"Edge too low: {edge:.3f} < {self.min_edge}"
        if confidence < self.min_confidence:
            return False, f"Confidence too low: {confidence:.3f} < {self.min_confidence}"
        if spread > self.max_spread:
            return False, f"Spread too wide: {spread:.3f} > {self.max_spread}"
        if liquidity < self.min_liquidity:
            return False, f"Insufficient liquidity: ${liquidity:.0f} < ${self.min_liquidity}"
        if regime == "sideways":
            return False, "Market regime: sideways (skip)"
        return True, ""


# ═══════════════════════════════════════════════════════════════
#  POSITION MANAGER
# ═══════════════════════════════════════════════════════════════
@dataclass
class Position:
    id: str
    asset: str
    direction: str
    entry_price: float
    entry_time: float
    bet_size: float
    token_id: str
    order_id: str
    model_prob: float
    market_prob: float
    edge: float
    confidence: float
    entry_reason: str
    status: str = "open"    # open | closed_tp | closed_sl | closed_time | closed_model
    exit_price: float = 0.0
    exit_time: float = 0.0
    pnl: float = 0.0
    pnl_pct: float = 0.0


class PositionManager:
    def __init__(self):
        self.positions: List[Position] = []
        self._id_counter = 0

    @property
    def open_positions(self) -> List[Position]:
        return [p for p in self.positions if p.status == "open"]

    def open_count(self) -> int:
        return len(self.open_positions)

    def can_open(self) -> bool:
        return self.open_count() < cfg.trading.max_open_positions

    def add(self, pos: Position):
        self.positions.append(pos)
        logger.info(
            f"[POS OPEN] {pos.asset} {pos.direction} | "
            f"${pos.bet_size:.2f} | edge={pos.edge:.3f} | conf={pos.confidence:.3f}"
        )

    def next_id(self) -> str:
        self._id_counter += 1
        return f"POS_{self._id_counter:04d}"

    def close(self, pos: Position, current_price: float, reason: str):
        """Mark position as closed and compute PnL."""
        pos.exit_price = current_price
        pos.exit_time  = time.time()

        if pos.direction == "YES":
            pnl_pct = (current_price - pos.entry_price) / (pos.entry_price + 1e-9)
        else:
            # For NO: if price goes down, NO price goes up
            pnl_pct = (pos.entry_price - current_price) / (pos.entry_price + 1e-9)

        pos.pnl_pct = round(pnl_pct, 4)
        pos.pnl     = round(pos.bet_size * pnl_pct, 4)
        pos.status  = reason

        logger.info(
            f"[POS CLOSE] {pos.asset} {pos.direction} | "
            f"reason={reason} | pnl=${pos.pnl:.2f} ({pos.pnl_pct*100:.1f}%)"
        )

    def should_exit(
        self, pos: Position, current_price: float,
        model_prob: float, confidence: float
    ) -> Optional[str]:
        """
        Check exit conditions. Returns exit reason or None.
        """
        now = time.time()
        elapsed_min = (now - pos.entry_time) / 60

        if pos.direction == "YES":
            pnl_pct = (current_price - pos.entry_price) / (pos.entry_price + 1e-9)
        else:
            pnl_pct = (pos.entry_price - current_price) / (pos.entry_price + 1e-9)

        # Take profit
        if pnl_pct >= cfg.trading.take_profit:
            return "closed_tp"

        # Stop loss
        if pnl_pct <= cfg.trading.stop_loss:
            return "closed_sl"

        # Time exit
        if elapsed_min >= cfg.trading.time_exit_minutes:
            return "closed_time"

        # Dynamic: model changed direction with high confidence
        if confidence > 0.65:
            if pos.direction == "YES" and model_prob < 0.45:
                return "closed_model"
            if pos.direction == "NO" and model_prob > 0.55:
                return "closed_model"

        return None

    def get_stats(self) -> dict:
        closed = [p for p in self.positions if p.status != "open"]
        if not closed:
            return {"trades": 0}
        wins  = [p for p in closed if p.pnl > 0]
        total_pnl = sum(p.pnl for p in closed)
        return {
            "trades": len(closed),
            "wins":   len(wins),
            "losses": len(closed) - len(wins),
            "winrate": len(wins) / len(closed),
            "total_pnl": round(total_pnl, 4),
            "avg_pnl":   round(total_pnl / len(closed), 4),
        }


# ═══════════════════════════════════════════════════════════════
#  RISK MANAGER
# ═══════════════════════════════════════════════════════════════
class RiskManager:
    def __init__(self):
        self.daily_loss: float = 0.0
        self.daily_start: float = time.time()
        self.consecutive_loss: int = 0
        self.cooldown_until: float = 0.0
        self.paused: bool = False
        self.pause_reason: str = ""

    def reset_daily(self):
        """Reset daily counters (call at start of each day)."""
        now = time.time()
        if now - self.daily_start >= 86400:
            self.daily_loss  = 0.0
            self.daily_start = now
            logger.info("[RISK] Daily counters reset.")

    def record_trade(self, pnl: float):
        """Update counters after a trade closes."""
        self.reset_daily()
        if pnl < 0:
            self.daily_loss       += abs(pnl)
            self.consecutive_loss += 1
        else:
            self.consecutive_loss = 0

        self._check_rules()

    def _check_rules(self):
        # Max daily loss
        if self.daily_loss >= cfg.risk.max_daily_loss:
            self.paused = True
            self.pause_reason = f"Max daily loss reached: ${self.daily_loss:.2f}"
            logger.warning(f"[RISK] BOT PAUSED — {self.pause_reason}")

        # Consecutive loss
        if self.consecutive_loss >= cfg.risk.max_consecutive_loss:
            cooldown_secs = cfg.risk.cooldown_minutes * 60
            self.cooldown_until = time.time() + cooldown_secs
            self.consecutive_loss = 0
            logger.warning(
                f"[RISK] Cooldown activated for {cfg.risk.cooldown_minutes} min "
                f"after {cfg.risk.max_consecutive_loss} consecutive losses."
            )

    def check_winrate(self, position_manager: PositionManager) -> bool:
        """Returns False if winrate is below minimum threshold."""
        closed = [p for p in position_manager.positions if p.status != "open"]
        window = closed[-cfg.risk.min_winrate_window:]
        if len(window) < cfg.risk.min_winrate_window:
            return True   # Not enough data yet
        wins = sum(1 for p in window if p.pnl > 0)
        winrate = wins / len(window)
        if winrate < cfg.risk.min_winrate:
            self.paused = True
            self.pause_reason = f"Winrate too low: {winrate:.1%} < {cfg.risk.min_winrate:.1%}"
            logger.warning(f"[RISK] BOT PAUSED — {self.pause_reason}")
            return False
        return True

    def is_trading_allowed(self) -> tuple:
        """Returns (allowed: bool, reason: str)."""
        if self.paused:
            return False, self.pause_reason

        now = time.time()
        if now < self.cooldown_until:
            remaining = int((self.cooldown_until - now) / 60)
            return False, f"Cooldown active ({remaining} min remaining)"

        return True, ""

    def resume(self):
        """Manually resume bot after reviewing situation."""
        self.paused = False
        self.pause_reason = ""
        logger.info("[RISK] Bot manually resumed.")
