"""
market_finder.py — CLI utility to discover Polymarket 15m crypto markets
and extract their condition IDs for use in .env config.

Usage:
    python market_finder.py
    python market_finder.py --asset BTC
    python market_finder.py --live    # shows live prices too
"""

import sys
import json
import argparse
import logging
import requests
from datetime import datetime
from typing import Optional

logging.basicConfig(level=logging.WARNING)

GAMMA_URL   = "https://gamma-api.polymarket.com"
CLOB_URL    = "https://clob.polymarket.com"


class MarketFinder:

    CRYPTO_KEYWORDS = {
        "BTC":  ["bitcoin", "btc", "will btc", "btc price", "bitcoin higher", "bitcoin lower"],
        "ETH":  ["ethereum", "eth", "will eth", "eth price", "ether higher"],
        "SOL":  ["solana", "sol", "will sol", "sol price", "solana higher"],
    }

    def __init__(self):
        self.session = requests.Session()
        self.session.headers["User-Agent"] = "Mozilla/5.0 PolymarketBot/1.0"

    def search_markets(self, keyword: str, limit: int = 20) -> list:
        """Fetch markets from Gamma API matching keyword."""
        try:
            resp = self.session.get(
                f"{GAMMA_URL}/markets",
                params={"search": keyword, "active": "true", "closed": "false", "limit": limit},
                timeout=15,
            )
            resp.raise_for_status()
            return resp.json().get("markets", [])
        except Exception as e:
            return []

    def get_clob_price(self, condition_id: str) -> Optional[float]:
        """Fetch YES price from CLOB."""
        try:
            resp = self.session.get(
                f"{CLOB_URL}/price",
                params={"token_id": condition_id, "side": "BUY"},
                timeout=10,
            )
            if resp.status_code == 200:
                return float(resp.json().get("price", 0))
        except Exception:
            pass
        return None

    def find_crypto_markets(self, asset: str, show_prices: bool = False) -> list:
        """Find all relevant markets for a crypto asset."""
        seen_ids = set()
        all_markets = []

        for kw in self.CRYPTO_KEYWORDS.get(asset.upper(), [asset.lower()]):
            markets = self.search_markets(kw)
            for m in markets:
                mid = m.get("id") or m.get("conditionId", "")
                if mid and mid not in seen_ids:
                    seen_ids.add(mid)
                    # Filter: must mention asset in question
                    question = m.get("question", "").lower()
                    if asset.lower() in question or "btc" in question.lower():
                        all_markets.append(m)

        # Sort by volume
        all_markets.sort(key=lambda m: float(m.get("volume", 0) or 0), reverse=True)

        if show_prices:
            for m in all_markets[:10]:
                cid = m.get("conditionId") or m.get("id", "")
                price = self.get_clob_price(cid)
                m["_live_yes_price"] = price

        return all_markets

    def display_market(self, m: dict, idx: int):
        """Pretty print market info."""
        q       = m.get("question", "N/A")[:80]
        cid     = m.get("conditionId") or m.get("id", "N/A")
        vol     = float(m.get("volume", 0) or 0)
        liq     = float(m.get("liquidity", 0) or 0)
        end_dt  = m.get("endDate") or m.get("endDateIso", "N/A")
        price   = m.get("_live_yes_price")

        print(f"\n  [{idx:02d}] {q}")
        print(f"       condition_id : {cid}")
        print(f"       volume       : ${vol:,.0f}")
        print(f"       liquidity    : ${liq:,.0f}")
        print(f"       ends         : {end_dt}")
        if price is not None:
            print(f"       YES price    : {price:.3f} ({price*100:.1f}%)")

    def run_interactive(self, assets: list = None, show_prices: bool = False):
        """Run full search and display results."""
        assets = assets or ["BTC", "ETH", "SOL"]
        found_ids = {}

        print("\n" + "="*65)
        print("  POLYMARKET MARKET FINDER — Crypto 15m Prediction Markets")
        print("="*65)

        for asset in assets:
            print(f"\n🔍 Searching {asset} markets...")
            markets = self.find_crypto_markets(asset, show_prices=show_prices)

            if not markets:
                print(f"  ⚠️  No active markets found for {asset}")
                continue

            print(f"  Found {len(markets)} market(s). Top results:")
            for i, m in enumerate(markets[:5]):
                self.display_market(m, i + 1)

            # Suggest best market (highest volume)
            best = markets[0]
            best_cid = best.get("conditionId") or best.get("id", "")
            found_ids[asset] = best_cid

        print("\n" + "="*65)
        print("  📋 SUGGESTED .env ENTRIES (highest volume markets):")
        print("="*65)
        for asset, cid in found_ids.items():
            print(f"  POLY_MARKET_{asset}={cid}")

        print("\n  ⚠️  IMPORTANT:")
        print("  - Verify each market manually on polymarket.com")
        print("  - Confirm it's a 15-minute price prediction market")
        print("  - Markets expire — re-run this tool periodically")
        print("  - Copy condition IDs to your .env file\n")

        return found_ids

    def monitor_prices(self, condition_ids: dict, interval_sec: int = 30):
        """Continuously monitor prices for given condition IDs."""
        print("\n📡 Live price monitor (Ctrl+C to stop)\n")
        try:
            while True:
                ts = datetime.utcnow().strftime("%H:%M:%S")
                print(f"\r[{ts}]", end="  ")
                for asset, cid in condition_ids.items():
                    if cid:
                        price = self.get_clob_price(cid)
                        if price:
                            print(f"{asset}: {price*100:.1f}%  ", end="")
                        else:
                            print(f"{asset}: N/A  ", end="")
                sys.stdout.flush()
                import time; time.sleep(interval_sec)
        except KeyboardInterrupt:
            print("\nMonitor stopped.")


def main():
    parser = argparse.ArgumentParser(description="Polymarket Market Finder")
    parser.add_argument("--asset",  type=str, default=None, help="BTC, ETH, or SOL")
    parser.add_argument("--live",   action="store_true",    help="Show live YES prices")
    parser.add_argument("--monitor",action="store_true",    help="Continuous price monitor")
    parser.add_argument("--json",   action="store_true",    help="Output raw JSON")
    args = parser.parse_args()

    finder = MarketFinder()
    assets = [args.asset.upper()] if args.asset else ["BTC", "ETH", "SOL"]

    if args.json:
        result = {}
        for asset in assets:
            markets = finder.find_crypto_markets(asset, show_prices=args.live)
            result[asset] = markets[:5]
        print(json.dumps(result, indent=2, default=str))
        return

    found_ids = finder.run_interactive(assets, show_prices=args.live)

    if args.monitor and found_ids:
        finder.monitor_prices(found_ids)


if __name__ == "__main__":
    main()
