"""
bot.py — Polymarket Auto-Trading Bot v2
Integrates: async data fetching, Telegram notifications, colorized console
"""

import os
import time
import logging
import datetime
from typing import Dict, Optional

from config import cfg
from async_fetcher import fetch_all_sync
from ml_model import ModelRegistry
from polymarket_client import PolymarketClient
from edge_risk_position import (
    EdgeCalculator, EdgeResult,
    PositionManager, Position,
    RiskManager,
)
from trade_logger import TradeLogger
from notifier import Notifier

logger = logging.getLogger(__name__)


class PolymarketBot:

    def __init__(self):
        self.models    = ModelRegistry()
        self.poly      = PolymarketClient()
        self.edge_calc = EdgeCalculator()
        self.positions = PositionManager()
        self.risk      = RiskManager()
        self.trade_log = TradeLogger()
        self.notifier  = Notifier()

        self._market_cache: Dict[str, dict] = {}
        self._last_train_time: float = 0
        self._daily_summary_sent: str = ""

        self.models.load_all()

    def run(self):
        self.notifier.on_info("Polymarket Bot started | Assets: " + ", ".join(cfg.trading.assets))
        logger.info("=" * 60)
        logger.info("  POLYMARKET BOT v2")
        logger.info(f"  Assets:    {cfg.trading.assets}")
        logger.info(f"  Min edge:  {cfg.edge.min_edge:.0%}  Min conf: {cfg.edge.min_confidence:.0%}")
        logger.info(f"  Bet range: ${cfg.trading.min_bet} – ${cfg.trading.max_bet}")
        logger.info("=" * 60)
        self._train_models()

        while True:
            try:
                self._tick()
                self._maybe_daily_summary()
            except KeyboardInterrupt:
                logger.info("Bot stopped.")
                stats = self.positions.get_stats()
                self.trade_log.print_summary(stats)
                self.notifier.on_daily_summary(stats)
                break
            except Exception as e:
                logger.error(f"Error: {e}", exc_info=True)
            self._sleep_to_next_candle()

    def _tick(self):
        ts = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        logger.info(f"\n{'─'*50}\n[TICK] {ts} UTC")

        if self._should_retrain():
            self._train_models()

        allowed, reason = self.risk.is_trading_allowed()
        if not allowed:
            self.notifier.on_risk("TRADING BLOCKED", reason)
            self._monitor_exits()
            return

        self.risk.check_winrate(self.positions)
        if not self.risk.is_trading_allowed()[0]:
            return

        # Fetch all assets concurrently
        market_data = fetch_all_sync(cfg.trading.assets)
        self._monitor_exits(market_data)
        if self.positions.can_open():
            self._evaluate_entries(market_data)

        stats = self.positions.get_stats()
        logger.info(
            f"[STATS] trades={stats.get('trades',0)} | "
            f"wr={stats.get('winrate',0):.1%} | "
            f"pnl=${stats.get('total_pnl',0):.2f} | "
            f"open={self.positions.open_count()}"
        )

    def _evaluate_entries(self, market_data: dict):
        for asset in cfg.trading.assets:
            if not self.positions.can_open():
                break
            if any(p.asset == asset for p in self.positions.open_positions):
                continue
            try:
                self._evaluate_asset(asset, market_data.get(asset, {}))
            except Exception as e:
                logger.error(f"[{asset}] Entry error: {e}", exc_info=True)

    def _evaluate_asset(self, asset: str, asset_data: dict):
        df = asset_data.get("df")
        ob_binance = asset_data.get("orderbook", {})
        if df is None or df.empty:
            self.trade_log.log_skip(asset, "No OHLCV data")
            return

        regime = self._get_regime(df)
        model  = self.models.get(asset)
        if not model.trained:
            self.trade_log.log_skip(asset, "Model not trained")
            return

        p_up, confidence = model.predict_proba(df)

        last = df.iloc[-1]
        if abs(float(last.get("price_mom_3", 0))) > 0.05:
            self.trade_log.log_skip(asset, "Extreme candle")
            return

        market = self._get_or_find_market(asset)
        if not market:
            self.trade_log.log_skip(asset, "No Polymarket market")
            return

        condition_id = market.get("conditionId") or market.get("id", "")
        if not condition_id:
            self.trade_log.log_skip(asset, "Missing condition ID")
            return

        price_data = self.poly.get_market_price(condition_id)
        ob_poly    = self.poly.get_orderbook_summary(condition_id)
        if not price_data:
            self.trade_log.log_skip(asset, "Polymarket price unavailable")
            return

        # Binance orderbook imbalance tweak
        imbalance = ob_binance.get("imbalance", 0)
        if confidence > 0.65 and p_up > 0.65 and imbalance < -0.3:
            confidence *= 0.85

        edge_result = self.edge_calc.calculate(
            asset, p_up, confidence, price_data, ob_poly, regime
        )
        if not edge_result.should_enter:
            self.trade_log.log_skip(asset, edge_result.reject_reason)
            return

        self._enter_position(asset, edge_result, condition_id, price_data, regime, df)

    def _enter_position(self, asset, er, condition_id, price_data, regime, df):
        entry_price = price_data["yes"] if er.direction == "YES" else price_data["no"]
        last = df.iloc[-1]
        feats = []
        if float(last.get("ema_cross_9_21", 0)) ==  1: feats.append("EMA9>21")
        if float(last.get("ema_cross_9_21", 0)) == -1: feats.append("EMA9<21")
        if float(last.get("rsi_14",  50)) < 35:         feats.append("RSI_OS")
        if float(last.get("rsi_14",  50)) > 65:         feats.append("RSI_OB")
        if float(last.get("macd_hist", 0)) > 0:         feats.append("MACD+")
        if float(last.get("vol_spike", 1)) > 1.5:       feats.append("VOL_SPIKE")
        if float(last.get("breakout_up",   0)) == 1:    feats.append("BRK_UP")
        if float(last.get("breakout_down", 0)) == 1:    feats.append("BRK_DN")
        reason = ", ".join(feats) or "ML_edge"

        order = self.poly.place_market_order(
            token_id=condition_id, side="BUY",
            amount_usdc=er.bet_size, direction=er.direction,
        )
        if not order:
            logger.error(f"[{asset}] Order placement failed.")
            return

        pos = Position(
            id=self.positions.next_id(), asset=asset,
            direction=er.direction, entry_price=entry_price,
            entry_time=time.time(), bet_size=er.bet_size,
            token_id=condition_id, order_id=order.get("orderID",""),
            model_prob=er.model_prob, market_prob=er.market_prob,
            edge=er.edge, confidence=er.confidence, entry_reason=reason,
        )
        self.positions.add(pos)
        self.trade_log.log_entry(pos, regime=regime)
        self.notifier.on_entry(pos)

    def _monitor_exits(self, market_data: dict = None):
        for pos in self.positions.open_positions[:]:
            try:
                self._check_exit(pos, market_data)
            except Exception as e:
                logger.error(f"[{pos.asset}] Exit error: {e}")

    def _check_exit(self, pos: Position, market_data: dict = None):
        price_data = self.poly.get_market_price(pos.token_id)
        if not price_data:
            return
        current = price_data["yes"] if pos.direction == "YES" else price_data["no"]
        p_up, confidence = 0.5, 0.5
        if market_data:
            df = market_data.get(pos.asset, {}).get("df")
            if df is not None and not df.empty:
                try:
                    p_up, confidence = self.models.get(pos.asset).predict_proba(df)
                except Exception:
                    pass
        reason = self.positions.should_exit(pos, current, p_up, confidence)
        if reason:
            self.positions.close(pos, current, reason)
            self.trade_log.log_exit(pos)
            self.risk.record_trade(pos.pnl)
            self.notifier.on_exit(pos)

    def _get_regime(self, df) -> str:
        if df.empty: return "unknown"
        last = df.iloc[-1]
        if float(last.get("atr_pct", 0)) > 0.025: return "high_volatility"
        if float(last.get("adx_14",  0)) > 25:    return "trending"
        return "sideways"

    def _get_or_find_market(self, asset: str) -> Optional[dict]:
        if asset in self._market_cache:
            return self._market_cache[asset]
        m = self.poly.find_crypto_market(asset)
        if m:
            self._market_cache[asset] = m
            logger.info(f"[{asset}] Market: {m.get('question','')[:60]}")
        return m

    def _should_retrain(self) -> bool:
        return (time.time() - self._last_train_time) > cfg.ml.retrain_interval_hours * 3600

    def _train_models(self):
        logger.info("[TRAIN] Retraining all models...")
        raw  = fetch_all_sync(cfg.trading.assets, limit=500)
        data = {a: raw[a]["df"] for a in cfg.trading.assets if not raw[a]["df"].empty}
        for asset, metrics in self.models.train_all(data).items():
            self.notifier.on_train(asset, metrics)
        self._last_train_time = time.time()

    def _sleep_to_next_candle(self):
        now  = time.time()
        slot = 15 * 60
        secs = max(((int(now / slot) + 1) * slot + 30) - now, 10)
        logger.info(f"[SLEEP] Next candle in {secs/60:.1f} min")
        time.sleep(secs)

    def _maybe_daily_summary(self):
        today = datetime.datetime.utcnow().strftime("%Y-%m-%d")
        if datetime.datetime.utcnow().hour == 0 and today != self._daily_summary_sent:
            stats = self.positions.get_stats()
            self.notifier.on_daily_summary(stats)
            self.trade_log.print_summary(stats)
            self._daily_summary_sent = today
            self.risk.daily_loss = 0
            self.risk.consecutive_loss = 0
            if self.risk.paused:
                self.risk.resume()
