"""
main.py — Entry point for Polymarket Auto-Trading Bot

Usage:
    python main.py               # Run live bot
    python main.py --backtest    # Run backtest only
    python main.py --train       # Train models, then exit
    python main.py --paper       # Paper trading mode (no real orders)
"""

import os
import sys
import logging
import argparse

# ── Load env vars before importing config ──────────────────────
from dotenv import load_dotenv
load_dotenv()

from config import cfg

# Inject API keys from env
cfg.binance.api_key    = os.getenv("BINANCE_API_KEY", "")
cfg.binance.api_secret = os.getenv("BINANCE_API_SECRET", "")
cfg.poly.api_key       = os.getenv("POLYMARKET_API_KEY", "")

# Optional: override Polymarket market condition IDs from env
cfg.poly.market_slugs = {
    "BTC_UP_15M": os.getenv("POLY_MARKET_BTC", ""),
    "ETH_UP_15M": os.getenv("POLY_MARKET_ETH", ""),
    "SOL_UP_15M": os.getenv("POLY_MARKET_SOL", ""),
}

from trade_logger import setup_logging


def run_bot():
    setup_logging(logging.INFO)
    from bot import PolymarketBot
    bot = PolymarketBot()
    bot.run()


def run_backtest():
    setup_logging(logging.INFO)
    from backtester import run_full_backtest
    results = run_full_backtest()
    return results


def run_train_only():
    setup_logging(logging.INFO)
    from data_fetcher import DataPipeline
    from ml_model import ModelRegistry

    logger = logging.getLogger(__name__)
    logger.info("Training models and exiting...")

    pipeline = DataPipeline()
    registry = ModelRegistry()

    data = {}
    for asset in cfg.trading.assets:
        df = pipeline.get_enriched_data(asset, limit=500)
        if not df.empty:
            data[asset] = df
        else:
            logger.warning(f"[{asset}] No data fetched.")

    results = registry.train_all(data)
    for asset, metrics in results.items():
        print(f"\n[{asset}] Training complete:")
        for k, v in metrics.items():
            print(f"  {k:<25} {v}")


def main():
    parser = argparse.ArgumentParser(description="Polymarket Auto-Trading Bot")
    parser.add_argument("--backtest", action="store_true", help="Run backtesting")
    parser.add_argument("--train",    action="store_true", help="Train models and exit")
    parser.add_argument("--paper",    action="store_true", help="Paper trading (no real orders)")
    args = parser.parse_args()

    if args.paper:
        # Force paper mode by clearing API key
        cfg.poly.api_key = ""
        os.environ["POLYMARKET_API_KEY"] = ""
        print("📝 PAPER TRADING MODE — no real orders will be placed")

    if args.backtest:
        run_backtest()
    elif args.train:
        run_train_only()
    else:
        run_bot()


if __name__ == "__main__":
    main()
