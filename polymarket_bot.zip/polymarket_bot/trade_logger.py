"""
trade_logger.py — CSV + console logging for all trade events
"""

import os
import csv
import json
import logging
import datetime
from typing import TYPE_CHECKING
from config import cfg

if TYPE_CHECKING:
    from edge_risk_position import Position

logger = logging.getLogger(__name__)


def setup_logging(level=logging.INFO):
    """Configure root logger with file + console handlers."""
    os.makedirs(cfg.log_dir, exist_ok=True)
    date_str = datetime.datetime.utcnow().strftime("%Y%m%d")
    log_file = os.path.join(cfg.log_dir, f"bot_{date_str}.log")

    fmt = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
    logging.basicConfig(
        level=level,
        format=fmt,
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(log_file, encoding="utf-8"),
        ]
    )
    logging.getLogger("urllib3").setLevel(logging.WARNING)


class TradeLogger:
    """Write every trade entry/exit to a CSV file."""

    FIELDS = [
        "timestamp", "event", "trade_id",
        "asset", "direction",
        "model_prob", "market_prob", "edge_pct",
        "confidence", "bet_size",
        "entry_price", "exit_price",
        "pnl_usdc", "pnl_pct",
        "exit_reason", "entry_reason",
        "regime",
    ]

    def __init__(self):
        os.makedirs(cfg.log_dir, exist_ok=True)
        date_str = datetime.datetime.utcnow().strftime("%Y%m%d")
        self.csv_path = os.path.join(cfg.log_dir, f"trades_{date_str}.csv")
        self._ensure_header()

    def _ensure_header(self):
        if not os.path.exists(self.csv_path):
            with open(self.csv_path, "w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=self.FIELDS)
                writer.writeheader()

    def log_entry(self, pos: "Position", regime: str = ""):
        row = {
            "timestamp":    datetime.datetime.utcnow().isoformat(),
            "event":        "ENTRY",
            "trade_id":     pos.id,
            "asset":        pos.asset,
            "direction":    pos.direction,
            "model_prob":   f"{pos.model_prob:.4f}",
            "market_prob":  f"{pos.market_prob:.4f}",
            "edge_pct":     f"{pos.edge*100:.2f}",
            "confidence":   f"{pos.confidence:.4f}",
            "bet_size":     f"{pos.bet_size:.2f}",
            "entry_price":  f"{pos.entry_price:.4f}",
            "exit_price":   "",
            "pnl_usdc":     "",
            "pnl_pct":      "",
            "exit_reason":  "",
            "entry_reason": pos.entry_reason,
            "regime":       regime,
        }
        self._write(row)
        logger.info(
            f"[ENTRY] {pos.asset} {pos.direction} | "
            f"edge={pos.edge*100:.1f}% | conf={pos.confidence*100:.0f}% | "
            f"${pos.bet_size:.2f} | reason: {pos.entry_reason}"
        )

    def log_exit(self, pos: "Position"):
        row = {
            "timestamp":    datetime.datetime.utcnow().isoformat(),
            "event":        "EXIT",
            "trade_id":     pos.id,
            "asset":        pos.asset,
            "direction":    pos.direction,
            "model_prob":   f"{pos.model_prob:.4f}",
            "market_prob":  f"{pos.market_prob:.4f}",
            "edge_pct":     f"{pos.edge*100:.2f}",
            "confidence":   f"{pos.confidence:.4f}",
            "bet_size":     f"{pos.bet_size:.2f}",
            "entry_price":  f"{pos.entry_price:.4f}",
            "exit_price":   f"{pos.exit_price:.4f}",
            "pnl_usdc":     f"{pos.pnl:.4f}",
            "pnl_pct":      f"{pos.pnl_pct*100:.2f}",
            "exit_reason":  pos.status,
            "entry_reason": pos.entry_reason,
            "regime":       "",
        }
        self._write(row)
        emoji = "✅" if pos.pnl > 0 else "❌"
        logger.info(
            f"{emoji} [EXIT] {pos.asset} {pos.direction} | "
            f"{pos.status} | pnl=${pos.pnl:.2f} ({pos.pnl_pct*100:.1f}%)"
        )

    def log_skip(self, asset: str, reason: str):
        logger.debug(f"[SKIP] {asset} — {reason}")

    def log_risk_event(self, event: str, detail: str = ""):
        logger.warning(f"[RISK] {event} {detail}")

    def _write(self, row: dict):
        with open(self.csv_path, "a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=self.FIELDS)
            writer.writerow(row)

    def print_summary(self, stats: dict):
        bar = "=" * 50
        print(f"\n{bar}")
        print("  POLYMARKET BOT — SESSION SUMMARY")
        print(bar)
        for k, v in stats.items():
            if isinstance(v, float):
                print(f"  {k:<20} {v:.4f}")
            else:
                print(f"  {k:<20} {v}")
        print(f"{bar}\n")
