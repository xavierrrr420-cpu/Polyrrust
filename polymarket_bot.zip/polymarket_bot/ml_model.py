"""
ml_model.py — Feature engineering + XGBoost / Random Forest / Ensemble model
"""

import os
import pickle
import logging
import numpy as np
import pandas as pd
from typing import Tuple, Optional
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import cross_val_score
from sklearn.metrics import accuracy_score, classification_report
from config import cfg

logger = logging.getLogger(__name__)

try:
    from xgboost import XGBClassifier
    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False
    logger.warning("XGBoost not installed. Falling back to RandomForest.")


# ─────────────────────────────────────────────────────────────
# FEATURE LIST (must match computed columns in data_fetcher)
# ─────────────────────────────────────────────────────────────
FEATURE_COLS = [
    # Technical
    "rsi_14",
    "ema_cross_9_21",
    "macd_hist",
    "bb_position",
    "bb_width",
    "atr_pct",
    "adx_14",
    # Price action
    "body_size",
    "upper_wick",
    "lower_wick",
    "candle_dir",
    "hh",
    "ll",
    "breakout_up",
    "breakout_down",
    # Momentum
    "price_mom_3",
    "price_mom_6",
    "price_mom_12",
    "ema_slope_9",
    "ema_slope_21",
    # Volume
    "vol_spike",
    "vol_trend",
    # Market regime proxy
    "session",
    "weekday",
]


def build_labels(df: pd.DataFrame, forward_candles: int = 1) -> pd.Series:
    """
    Label: 1 if close[t+1] > close[t], else 0.
    Using 1-candle forward (15m).
    """
    future_close = df["close"].shift(-forward_candles)
    return (future_close > df["close"]).astype(int)


def prepare_features(df: pd.DataFrame) -> pd.DataFrame:
    """Extract and clip extreme values from feature columns."""
    available = [c for c in FEATURE_COLS if c in df.columns]
    X = df[available].copy()

    # Clip extreme outliers (±5 std per feature)
    for col in X.columns:
        mean, std = X[col].mean(), X[col].std()
        X[col] = X[col].clip(mean - 5 * std, mean + 5 * std)

    return X.fillna(0)


# ─────────────────────────────────────────────────────────────
# MODEL MANAGER
# ─────────────────────────────────────────────────────────────
class MLModel:
    def __init__(self, asset: str, model_type: str = None):
        self.asset = asset
        self.model_type = model_type or cfg.ml.model_type
        self.model = None
        self.scaler = StandardScaler()
        self.feature_cols = FEATURE_COLS.copy()
        self.model_path = os.path.join(cfg.models_dir, f"{asset}_{self.model_type}.pkl")
        self.trained = False
        self.last_train_time: Optional[float] = None
        self._build_model()

    def _build_model(self):
        """Instantiate the model based on config."""
        if self.model_type == "xgboost" and XGBOOST_AVAILABLE:
            self.model = XGBClassifier(
                n_estimators=200,
                max_depth=5,
                learning_rate=0.05,
                subsample=0.8,
                colsample_bytree=0.8,
                eval_metric="logloss",
                random_state=42,
                n_jobs=-1,
            )
        elif self.model_type == "ensemble":
            estimators = [
                ("rf", RandomForestClassifier(n_estimators=100, max_depth=6, random_state=42)),
                ("lr", LogisticRegression(max_iter=500, C=0.5, random_state=42)),
            ]
            if XGBOOST_AVAILABLE:
                estimators.append(("xgb", XGBClassifier(
                    n_estimators=100, max_depth=4, learning_rate=0.05,
                    eval_metric="logloss", random_state=42
                )))
            self.model = VotingClassifier(estimators=estimators, voting="soft")
        else:
            # Default: Random Forest
            self.model = RandomForestClassifier(
                n_estimators=200,
                max_depth=7,
                min_samples_leaf=10,
                random_state=42,
                n_jobs=-1,
            )

    def train(self, df: pd.DataFrame) -> dict:
        """Train model on historical data. Returns metrics."""
        X = prepare_features(df)
        y = build_labels(df)

        # Align and drop last row (no future label)
        X = X.iloc[:-1]
        y = y.iloc[:-1]

        if len(X) < cfg.ml.min_train_samples:
            logger.warning(f"[{self.asset}] Not enough data to train: {len(X)} samples")
            return {"status": "insufficient_data"}

        # Remove any remaining NaN
        mask = ~(X.isnull().any(axis=1) | y.isnull())
        X, y = X[mask], y[mask]

        # Scale
        X_scaled = self.scaler.fit_transform(X)

        # Cross-val score
        cv_scores = cross_val_score(self.model, X_scaled, y, cv=5, scoring="accuracy")

        # Final fit on all data
        self.model.fit(X_scaled, y)
        self.trained = True
        self.feature_cols = list(X.columns)

        import time
        self.last_train_time = time.time()

        metrics = {
            "status": "trained",
            "samples": len(X),
            "cv_accuracy_mean": float(cv_scores.mean()),
            "cv_accuracy_std": float(cv_scores.std()),
            "feature_count": len(self.feature_cols),
        }
        logger.info(f"[{self.asset}] Model trained | CV acc: {cv_scores.mean():.3f} ± {cv_scores.std():.3f}")
        self.save()
        return metrics

    def predict_proba(self, df: pd.DataFrame) -> Tuple[float, float]:
        """
        Predict probability of UP for the LAST candle.
        Returns (p_up, confidence).
        confidence = distance of p_up from 0.5, scaled to [0, 1]
        """
        if not self.trained:
            raise RuntimeError(f"[{self.asset}] Model not trained yet.")

        X = prepare_features(df)
        # Use only trained features
        available = [c for c in self.feature_cols if c in X.columns]
        X = X[available].fillna(0)

        last_row = X.iloc[[-1]]
        X_scaled = self.scaler.transform(last_row)
        proba = self.model.predict_proba(X_scaled)[0]

        # proba[1] = P(up), proba[0] = P(down)
        p_up = float(proba[1]) if len(proba) > 1 else float(proba[0])
        confidence = abs(p_up - 0.5) * 2.0  # 0 = uncertain, 1 = very confident

        return p_up, confidence

    def feature_importance(self) -> pd.Series:
        """Return feature importances (XGBoost / RF)."""
        if hasattr(self.model, "feature_importances_"):
            return pd.Series(
                self.model.feature_importances_,
                index=self.feature_cols
            ).sort_values(ascending=False)
        return pd.Series()

    def save(self):
        os.makedirs(cfg.models_dir, exist_ok=True)
        with open(self.model_path, "wb") as f:
            pickle.dump({"model": self.model, "scaler": self.scaler,
                         "features": self.feature_cols, "type": self.model_type}, f)
        logger.info(f"[{self.asset}] Model saved → {self.model_path}")

    def load(self) -> bool:
        if not os.path.exists(self.model_path):
            return False
        try:
            with open(self.model_path, "rb") as f:
                data = pickle.load(f)
            self.model        = data["model"]
            self.scaler       = data["scaler"]
            self.feature_cols = data["features"]
            self.trained      = True
            logger.info(f"[{self.asset}] Model loaded from {self.model_path}")
            return True
        except Exception as e:
            logger.error(f"[{self.asset}] Model load error: {e}")
            return False


# ─────────────────────────────────────────────────────────────
# MODEL REGISTRY
# ─────────────────────────────────────────────────────────────
class ModelRegistry:
    """Manage one model per asset."""
    def __init__(self):
        self.models = {
            asset: MLModel(asset) for asset in cfg.trading.assets
        }

    def get(self, asset: str) -> MLModel:
        return self.models[asset]

    def train_all(self, data: dict):
        """Train all models. data = {asset: DataFrame}"""
        results = {}
        for asset, df in data.items():
            if asset in self.models:
                results[asset] = self.models[asset].train(df)
        return results

    def load_all(self):
        for asset, model in self.models.items():
            loaded = model.load()
            if not loaded:
                logger.info(f"[{asset}] No saved model found, will train from scratch.")
