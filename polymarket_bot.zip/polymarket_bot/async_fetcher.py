"""
async_fetcher.py — Async parallel data fetching for all assets simultaneously.
Replaces sequential calls in DataPipeline with concurrent aiohttp requests.
"""

import asyncio
import logging
import numpy as np
import pandas as pd
import aiohttp
from typing import Dict, Optional
from data_fetcher import IndicatorEngine
from config import cfg

logger = logging.getLogger(__name__)

BASE_URL = "https://api.binance.com"


async def _fetch_klines(
    session: aiohttp.ClientSession,
    asset: str,
    interval: str = "15m",
    limit: int = 200,
) -> tuple[str, pd.DataFrame]:
    symbol = cfg.binance.symbol_map.get(asset)
    url    = f"{BASE_URL}/api/v3/klines"
    params = {"symbol": symbol, "interval": interval, "limit": limit}
    try:
        async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=10)) as resp:
            resp.raise_for_status()
            raw = await resp.json()
    except Exception as e:
        logger.error(f"Async klines error [{asset}]: {e}")
        return asset, pd.DataFrame()

    cols = ["open_time","open","high","low","close","volume",
            "close_time","quote_vol","trades","taker_buy_base","taker_buy_quote","ignore"]
    df = pd.DataFrame(raw, columns=cols)
    df = df[["open_time","open","high","low","close","volume","trades"]].copy()
    for c in ["open","high","low","close","volume"]:
        df[c] = df[c].astype(float)
    df["trades"]    = df["trades"].astype(int)
    df["open_time"] = pd.to_datetime(df["open_time"], unit="ms")
    df.set_index("open_time", inplace=True)
    return asset, df


async def _fetch_orderbook(
    session: aiohttp.ClientSession,
    asset: str,
    depth: int = 20,
) -> tuple[str, dict]:
    symbol = cfg.binance.symbol_map.get(asset)
    url    = f"{BASE_URL}/api/v3/depth"
    params = {"symbol": symbol, "limit": depth}
    try:
        async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=10)) as resp:
            resp.raise_for_status()
            ob = await resp.json()
        bids = np.array(ob["bids"], dtype=float)
        asks = np.array(ob["asks"], dtype=float)
        bid_vol = bids[:, 1].sum()
        ask_vol = asks[:, 1].sum()
        return asset, {
            "bid_vol":   float(bid_vol),
            "ask_vol":   float(ask_vol),
            "imbalance": float((bid_vol - ask_vol) / (bid_vol + ask_vol + 1e-9)),
            "best_bid":  float(bids[0, 0]),
            "best_ask":  float(asks[0, 0]),
            "spread":    float(asks[0, 0] - bids[0, 0]),
        }
    except Exception as e:
        logger.warning(f"Async orderbook error [{asset}]: {e}")
        return asset, {}


async def fetch_all_assets(
    assets: list = None,
    interval: str = "15m",
    limit: int = 200,
    include_orderbook: bool = True,
) -> Dict[str, dict]:
    """
    Fetch OHLCV + orderbook for all assets concurrently.
    Returns dict: { asset: { "df": DataFrame, "orderbook": dict } }
    """
    assets  = assets or cfg.trading.assets
    ie      = IndicatorEngine()
    results: Dict[str, dict] = {a: {"df": pd.DataFrame(), "orderbook": {}} for a in assets}

    headers = {}
    if cfg.binance.api_key:
        headers["X-MBX-APIKEY"] = cfg.binance.api_key

    async with aiohttp.ClientSession(headers=headers) as session:
        tasks = [_fetch_klines(session, a, interval, limit) for a in assets]
        if include_orderbook:
            tasks += [_fetch_orderbook(session, a) for a in assets]

        responses = await asyncio.gather(*tasks, return_exceptions=True)

    # Parse klines
    for item in responses[:len(assets)]:
        if isinstance(item, Exception):
            continue
        asset, df = item
        if not df.empty:
            df = ie.compute_all(df)
            results[asset]["df"] = df

    # Parse orderbooks
    if include_orderbook:
        for item in responses[len(assets):]:
            if isinstance(item, Exception):
                continue
            asset, ob = item
            results[asset]["orderbook"] = ob

    return results


def fetch_all_sync(assets=None, interval="15m", limit=200) -> Dict[str, dict]:
    """Synchronous wrapper — use this from the main bot loop."""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # If already in async context (e.g. Jupyter), use nest_asyncio
            import nest_asyncio
            nest_asyncio.apply()
        return loop.run_until_complete(
            fetch_all_assets(assets, interval, limit)
        )
    except RuntimeError:
        return asyncio.run(fetch_all_assets(assets, interval, limit))
